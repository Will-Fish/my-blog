---
name: Professional Creative Persona
colors:
  surface: '#f8faf6'
  surface-dim: '#d8dbd7'
  surface-bright: '#f8faf6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f1'
  surface-container: '#eceeeb'
  surface-container-high: '#e7e9e5'
  surface-container-highest: '#e1e3e0'
  on-surface: '#191c1b'
  on-surface-variant: '#404944'
  inverse-surface: '#2e312f'
  inverse-on-surface: '#eff1ee'
  outline: '#707974'
  outline-variant: '#bfc9c3'
  surface-tint: '#2b6954'
  primary: '#003527'
  on-primary: '#ffffff'
  primary-container: '#064e3b'
  on-primary-container: '#80bea6'
  inverse-primary: '#95d3ba'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#4f1f19'
  on-tertiary: '#ffffff'
  tertiary-container: '#6b342d'
  on-tertiary-container: '#ea9e93'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b0f0d6'
  primary-fixed-dim: '#95d3ba'
  on-primary-fixed: '#002117'
  on-primary-fixed-variant: '#0b513d'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#ffdad5'
  tertiary-fixed-dim: '#ffb4a9'
  on-tertiary-fixed: '#380d08'
  on-tertiary-fixed-variant: '#6e372f'
  background: '#f8faf6'
  on-background: '#191c1b'
  surface-variant: '#e1e3e0'
typography:
  headline-xl:
    fontFamily: Newsreader
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.1'
  headline-lg:
    fontFamily: Newsreader
    fontSize: 32px
    fontWeight: '500'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Newsreader
    fontSize: 24px
    fontWeight: '500'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  container-max: 1200px
  gutter: 24px
---

## Brand & Style
The design system is anchored in a philosophy of "Editorial Minimalism." It is designed to project an image of a professional who is both highly organized and intellectually creative. By blending the utility of modern SaaS interfaces with the sophisticated pacing of a digital journal, the design system creates an environment of quiet confidence.

The aesthetic follows a **Modern Corporate** approach infused with **Minimalist** principles. It prioritizes generous white space, intentional alignment, and a high-contrast relationship between text and background. The goal is to evoke a sense of calm authority, ensuring the user feels they are in the hands of a disciplined expert.

## Colors
The palette is restrained and professional, centered on a "Deep Emerald" primary tone that signals growth and stability. 

- **Primary:** A sophisticated Deep Emerald (#064E3B) used for high-emphasis actions and branding.
- **Secondary/Neutral:** A series of cool Slates and Grays to handle borders, secondary text, and iconography without competing for attention.
- **Backgrounds:** The primary background is a very light "Ghost Gray" (#F8FAFC) to provide a softer canvas than pure white, while "Paper White" (#FFFFFF) is reserved for cards and surfaces to create depth.
- **Accent:** A brighter "Vibrant Emerald" is used sparingly for success states or subtle highlights to maintain a creative spark.

## Typography
The typography strategy relies on a sophisticated "Serif-over-Sans" pairing. 

**Newsreader** is utilized for headlines to provide a literary, authoritative character. Its slight eccentricities reflect a creative personality. **Inter** is the workhorse for all functional UI elements, navigation, and body copy, chosen for its exceptional legibility and neutral, systematic feel. 

Large-scale headlines should use tighter line-heights, while body copy is given ample leading (1.5–1.6) to ensure a comfortable, long-form reading experience. Labels and navigation items should use `label-sm` with a slight letter-spacing increase to enhance clarity at smaller sizes.

## Layout & Spacing
The design system employs a **Fixed Grid** model for desktop to maintain a curated, editorial feel, while transitioning to a fluid layout for mobile devices. 

The layout is built on a 12-column grid with a maximum container width of 1200px. A strict 8px base unit (the "spacing-base") governs all padding and margins. Vertical rhythm is established through large "XL" gaps between major sections to emphasize the minimalist aesthetic and give content room to breathe. Components should favor internal padding of `md` (24px) to ensure they never feel cramped.

## Elevation & Depth
Depth in this design system is achieved through **Ambient Shadows** and tonal layering rather than heavy borders. 

- **Surface Layering:** The background is the lowest level. Cards and containers sit on top using a pure white surface.
- **Shadows:** Shadows are highly diffused and low-opacity. Use a multi-layered shadow approach: a small, sharp shadow for definition combined with a large, soft, transparent blur (e.g., 10% opacity of the primary emerald or a deep slate) to simulate natural light.
- **Interactivity:** Hover states should involve a subtle vertical lift (2-4px) and a slight increase in shadow spread to provide clear, tactile feedback.

## Shapes
The shape language is defined by "Soft Professionalism." 

The design system uses a standard corner radius of **8px (Level 2)** for all primary components like cards, input fields, and buttons. This creates a balance between the "sharp" look of traditional corporate finance and the "pill-shaped" look of consumer social apps. Larger containers or featured image blocks may utilize `rounded-xl` (24px) for a more modern, friendly touch.

## Components
- **Buttons:** Use the Primary Emerald for main actions with white text. Secondary buttons should be Ghost Gray with Slate text. All buttons feature a 0.2s transition for hover states involving a slight darkening of the background color.
- **Cards:** These are the primary containers. They must have a white background, the standard 8px radius, and the ambient shadow defined in the Elevation section. No borders should be used on cards unless they are interactive "ghost" cards.
- **Chips/Tags:** Used for categorization. These should have a very light tint of the primary color (Emerald at 10% opacity) with dark emerald text to maintain a monochromatic, clean look.
- **Input Fields:** Use a subtle 1px border in Light Gray. On focus, the border should transition to the Primary Emerald with a soft outer glow.
- **Lists:** Use ample vertical padding (16px) between list items, separated by a hairline 1px divider in a very light neutral tone.
- **Hover States:** Any interactive card or list item should utilize a "lift and glow" effect—shifting up slightly while the shadow becomes more pronounced.